import Controller.*;
public class Run {
    public static void main(String[] args) {
        GameController StartGame = new GameController();
    }
}
